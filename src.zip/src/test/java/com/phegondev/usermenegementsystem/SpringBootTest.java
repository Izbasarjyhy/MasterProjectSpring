package com.phegondev.usermenegementsystem;

public @interface SpringBootTest {
}
