package com.phegondev.usermenegementsystem;

import org.junit.jupiter.api.Test;

@SpringBootTest
class UsermenegementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
